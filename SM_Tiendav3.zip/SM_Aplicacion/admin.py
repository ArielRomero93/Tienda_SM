from django.contrib import admin
from SM_Aplicacion.models import Clientes, Proveedores, Productos, Ventas, VentaDetalle

# Register your models here.

class AdminClientes(admin.ModelAdmin):
    list_display = ('nombre', 'numeroDocumento', 'telefono')
    list_filter = ('nombre', 'numeroDocumento')

class AdminProveedores(admin.ModelAdmin):
    list_display = ('nombre','numeroDocumento', 'telefono')
    list_filter = ('nombre', 'numeroDocumento')

class AdminProductos(admin.ModelAdmin):
    list_display = ('nombre', 'categoria')

class AdminVentas(admin.ModelAdmin):
    list_display = ['fecha']

class AdminVentaDetalle(admin.ModelAdmin):
    list_display = ('cantidad', 'subTotal')


admin.site.site_header = 'Tienda SM'
admin.site.site_title = 'Tienda SM'
admin.site.index_title = 'Archivos'


admin.site.register(Clientes, AdminClientes)
admin.site.register(Proveedores, AdminProveedores)
admin.site.register(Productos, AdminProductos)
admin.site.register(Ventas, AdminVentas)
admin.site.register(VentaDetalle, AdminVentaDetalle)