from django.apps import AppConfig


class SmAplicacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SM_Aplicacion'
