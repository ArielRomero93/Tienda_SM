from django.db.models import Q
from django.forms import inlineformset_factory
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import HttpResponse, Http404
from .models import Clientes, Proveedores, Productos, Ventas, VentaDetalle
from .forms import ClientesForm, ClienteReadOnlyForm, ProveedoresForm, ProductosForm, VentasForm, VentaDetalleForm, \
    VentaDetalleFormset
from django.urls import reverse


# Create your views here.
class SuccessMessageMixin:
    success_message = ''

    def form_valid(self, form):
        response = super().form_valid(form)
        success_message = self.get_success_message(form.cleaned_data)
        if success_message:
            messages.success(self.request, success_message)
        return response

    def get_success_message(self, cleaned_data):
        return self.success_message % cleaned_data


def bienvenidos(request):
    mensaje = f"<html><h1>Bienvenidos a Inmobiliaria Carena</h1> " \
              f"<p>Ya hay {Clientes.objects.count()} Clientes...<p></html>"
    return HttpResponse(mensaje)


def inicio(request):
    return render(request, 'paginas/inicio.html')


# CLIENTES

def clientes(request):
    termino_busqueda = request.GET.get('termino_busqueda')
    clientes = Clientes.objects.all()
    if termino_busqueda:
        clientes = clientes.filter(
            Q(nombre__icontains=termino_busqueda) |  # Filtrar por nombre que contenga el término de búsqueda
            Q(numeroDocumento__icontains=termino_busqueda) |  # Filtrar por numero de Documento que contenga el término de búsqueda
            Q(email__icontains=termino_busqueda)  # Filtrar por email que contenga el término de búsqueda
        )
    return render(request, 'clientes/index.html', {'clientes': clientes, 'termino_busqueda': termino_busqueda})


def buscar_clientes(request):
    query = request.GET.get('q')
    if query is not None:
        clientes = Clientes.objects.filter(
            Q(nombre__icontains=query) |  # Filtrar por nombre que contenga el término de búsqueda
            Q(numeroDocumento__icontains=query) |  # Filtrar por numero de Documento que contenga el término de búsqueda
            Q(email__icontains=query)  # Filtrar por email que contenga el término de búsqueda
        )
    else:
        clientes = Clientes.objects.all()
    return render(request, 'clientes/index.html', {'clientes': clientes})


def detalle_cliente(request, id):
    cliente = get_object_or_404(Clientes, pk=id)
    context = {'cliente': cliente}
    return render(request, 'clientes/ver_cliente.html', context)


def crear_cliente(request):
    if request.method == 'POST':
        formulario = ClientesForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm()

    return render(request, 'clientes/crear.html', {'formulario': formulario})


def editar_cliente(request, id):
    cliente = Clientes.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ClientesForm(request.POST, instance=cliente)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm(instance=cliente)
    url = reverse('editar_cliente', kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'clientes/editar.html', {'formulario': formulario, 'url': url})


def eliminar_cliente(request, id):
    cliente = Clientes.objects.get(id=id)
    cliente.delete()
    return redirect('clientes')


# PROVEEDORES
def proveedores(request):
    proveedores = Proveedores.objects.all()
    return render(request, 'proveedores/index.html', {'proveedores': proveedores})


def detalle_proveedor(request, id):
    proveedor = get_object_or_404(Proveedores, pk=id)
    context = {'proveedor': proveedor}
    return render(request, 'proveedores/ver_proveedor.html', context)


def crear_proveedor(request):
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm()

    return render(request, 'proveedores/crear.html', {'formulario': formulario})


def editar_proveedor(request, id):
    proveedor = Proveedores.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST, instance=proveedor)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm(instance=proveedor)
    url = reverse('editar_proveedor',
                  kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'proveedores/editar.html', {'formulario': formulario, 'url': url})


def eliminar_proveedor(request, id):
    proveedor = Proveedores.objects.get(id=id)
    proveedor.delete()
    return redirect('proveedores')


# PRODUCTOS
def productos(request):
    productos = Productos.objects.all()
    return render(request, 'productos/index.html', {'productos': productos})


# def detalle_producto(request, pk):
#     producto = get_object_or_404(Productos, pk=pk)
#     costo_total = producto.precioCosto * producto.cantidad
#     return render(request, 'productos/ver_producto.html', {'producto': producto})
def detalle_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    costo_total = producto.precioCosto * producto.cantidad  # calcula el costo total del producto
    context = {
        'producto': producto,
        'costo_total': costo_total,
    }
    return render(request, 'productos/ver_producto.html', context)


def crear_producto(request):
    if request.method == 'POST':
        formulario = ProductosForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm()
    return render(request, 'productos/crear.html', {'formulario': formulario})


def editar_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    if request.method == 'POST':
        formulario = ProductosForm(request.POST, instance=producto)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm(instance=producto)
        url = reverse('editar_producto',
                      kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'productos/editar.html', {'formulario': formulario, 'url': url})


def eliminar_producto(request, id):
    producto = Productos.objects.get(id=id)
    producto.delete()
    return redirect('productos')


# VENTAS

def ventas(request):
    ventas = Ventas.objects.all()
    context = {'ventas': ventas}
    return render(request, 'ventas/index.html', context)


# def crear_venta(request):
#     if request.method == 'POST':
#         ventas_form = VentasForm(request.POST)
#         venta_detalle_formset = VentaDetalleFormset(request.POST)
#         if ventas_form.is_valid() and venta_detalle_formset.is_valid():
#             venta = ventas_form.save()
#             venta_detalle_formset.instance = venta
#             venta_detalle_formset.save()
#             return redirect('ventas')
#     else:
#         ventas_form = VentasForm()
#         venta_detalle_formset = VentaDetalleFormset(instance=Ventas())
#     context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
#     return render(request, 'ventas/crear.html', context)


def crear_venta(request):
    venta = Ventas()  # crear objeto Vacio
    if request.method == 'POST':
        ventas_form = VentasForm(request.POST, instance=venta) # pasar la instancia
        venta_detalle_formset = VentaDetalleFormset(request.POST, instance=venta)
        if ventas_form.is_valid() and venta_detalle_formset.is_valid():
            venta = ventas_form.save()
            venta_detalle_formset.instance = venta
            venta_detalle_formset.save()
            return redirect('ventas')
        else:
            print(ventas_form.errors)
            print(venta_detalle_formset.errors)
    else:
        ventas_form = VentasForm(instance=venta) # pasar la instancia
        venta_detalle_formset = VentaDetalleFormset(instance=venta)
    context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
    return render(request, 'ventas/crear.html', context)

# def crear_venta(request):
#     VentaDetalleFormset = inlineformset_factory(Ventas, VentaDetalle, form=VentaDetalleForm, extra=10)
#     if request.method == 'POST':
#         ventas_form = VentasForm(request.POST)
#         if ventas_form.is_valid():
#             venta = ventas_form.save()
#             venta_detalle_formset = VentaDetalleFormset(request.POST, instance=venta)
#             if venta_detalle_formset.is_valid():
#                 venta_detalle_formset.save()
#                 return redirect('ventas')
#     else:
#         ventas_form = VentasForm()
#         venta_detalle_formset = VentaDetalleFormset(instance=Ventas())
#     context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
#     return render(request, 'ventas/crear.html', context)


# def ventas_edit(request, pk=None):
#     if pk is not None:
#         venta = get_object_or_404(Ventas, pk=pk)
#
#         detalle = VentaDetalle.objects.filter(idListaPrecio=venta)
#     else:
#         venta = None
#         detalle = VentaDetalleFormset(queryset=Ventas.objects.none())
#
#     if request.method == "POST":
#         t_form = VentasForm(request.POST, instance=venta)
#         if t_form.is_valid():
#             updated_lista = t_form.save(commit=False)
#             # updated_lista.save()
#
#             i_formset = VentaDetalleFormset(request.POST, instance=updated_lista)
#
#             if i_formset.is_valid():
#                 i_formset.save()
#
#                 if venta is None:
#                     messages.success(request, "Venta Finalizada Con Exito".format(updated_lista))
#                 else:
#                     messages.success(request, "Venta Modificada Con Exito".format(updated_lista))
#                 return redirect("/venta/edit/" + str(updated_lista.pk), ventas_edit)  # Revisar Plantilla
#     else:
#         t_form = VentasForm(instance=venta)
#         i_formset = VentaDetalleFormset(instance=venta)
#         i_formset.extra = 10 if i_formset.queryset.count() < 1 else 1
#
#     return render(request, "ventaform.html",
#                   {"method": request.method, "t_form": t_form, 'i_formset': i_formset})  # Revisar Plantilla

# FUNCIONES AUXILIARES
