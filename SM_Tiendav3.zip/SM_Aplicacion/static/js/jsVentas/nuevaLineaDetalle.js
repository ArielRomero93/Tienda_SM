document.addEventListener("DOMContentLoaded", function() {
        var addDetalleBtn = document.getElementById("add-detalle");
        addDetalleBtn.addEventListener("click", function() {
            var detalleFormset = document.getElementById("detalle-formset");
            var lastDetalleRow = detalleFormset.lastElementChild;
            var newDetalleRow = lastDetalleRow.cloneNode(true);
            detalleFormset.appendChild(newDetalleRow);
        });
    });