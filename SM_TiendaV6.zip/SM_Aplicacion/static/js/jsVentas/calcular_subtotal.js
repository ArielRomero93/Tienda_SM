$(document).on('change', '.detalle-formset-row input', function() {
    var total = 0;
    $('.detalle-formset-row').each(function() {
        var cantidad = $(this).find('input[name$="cantidad"]').val();
        var preciounitario = $(this).find('input[name$="precioUnitario"]').val();
        var subtotal = cantidad * preciounitario;
        $(this).find('input[name$="subTotal"]').val(subtotal.toFixed(2));
        if (!isNaN(subtotal)) {
            total += subtotal;
        }
    });
    $('.ventaCabecera').find('input[name$="precioTotal"]').val(total.toFixed(2));
    console.log(`Total: ${total}`);
});
