$(document).ready(function() {
    var form_count = 1;
    $('#add-detalle').click(function() {
        var row = '<div class="detalle-formset-row">' + $('.detalle-formset-empty-row').html().replace(/__prefix__/g, form_count) + '</div>';
        form_count++;
        $('#detalle-formset').append(row);
    });
});
