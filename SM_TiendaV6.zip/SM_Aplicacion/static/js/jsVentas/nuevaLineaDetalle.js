document.addEventListener("DOMContentLoaded", function() {
  // Obtiene el botón de "añadir detalle"
  var addDetalleBtn = document.getElementById("add-detalle");

  // Añade un controlador de eventos al botón
  addDetalleBtn.addEventListener("click", function() {
    // Obtiene el formulario de detalles y su última fila
    var detalleFormset = document.getElementById("detalle-formset");
    var lastDetalleRow = detalleFormset.lastElementChild;

    // Clona la última fila y la añade al formulario
    var newDetalleRow = lastDetalleRow.cloneNode(true);
    newDetalleRow.querySelector("Select").value = ""; // Limpiar el valor del campo de selección de producto
    newDetalleRow.querySelector("input[type='number']").value = 0; // Establecer la cantidad en 0
    detalleFormset.appendChild(newDetalleRow);
  });-
});
