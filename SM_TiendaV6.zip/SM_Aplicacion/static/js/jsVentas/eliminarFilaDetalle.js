$(document).ready(function() {
    // Agregar manejador de eventos para el botón "Agregar detalle"
    $('#add-detalle').click(function() {
        // Clonar la última fila del detalle de venta
        var $lastRow = $('.detalle-formset-row:last');
        var $newRow = $lastRow.clone();

        // Reiniciar los valores de los campos en la nueva fila
        $newRow.find('input[type="text"]').val('');
        $newRow.find('input[type="number"]').val('0');
        $newRow.find('.delete-row-btn').show();

        // Insertar la nueva fila en el formulario
        $lastRow.after($newRow);
    });

    // Agregar manejador de eventos para los botones "Eliminar" en cada fila del detalle
    $('#detalle-formset').on('click', '.delete-row-btn', function() {
        $(this).closest('.detalle-formset-row').remove();
    });
});