function exportToExcel() {
  // Obtener la tabla
  var table = document.getElementById("dataTable");
  console.log(table);
  // Convertir la tabla en una matriz de objetos
var rows = [];
for (var i = 0; i < table.rows.length; i++) {
  var row = table.rows[i];
  var cells = row.cells;
  var rowData = {};
  for (var j = 0; j < (cells.length - 1); j++) {
    rowData[j] = cells[j].textContent;
  }
  rows.push(rowData);
}


  // Crear la hoja de cálculo
  var sheet = XLSX.utils.json_to_sheet(rows);

  // Crear el libro de trabajo y agregar la hoja de cálculo
  var workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, "Ventas");

  // Descargar la hoja de cálculo en formato Excel
  var date = new Date().toISOString().slice(0, 19).replace(/-/g, "");
  var filename = "ventas_" + date + ".xlsx";
  XLSX.writeFile(workbook, filename);
}
