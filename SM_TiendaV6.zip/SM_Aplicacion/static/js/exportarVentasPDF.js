function exportarPDF() {
  // Obtener los datos de la tabla
  var rows = [];
  var table = document.getElementById("dataTable");
  var total = 0;
  for (var i = 1, row; (row = table.rows[i]); i++) {
    var rowData = [
      row.cells[0].textContent,
      row.cells[1].textContent,
      row.cells[2].textContent,
      row.cells[3].textContent,
      row.cells[4].textContent,
    ];


    // Sumar el valor de la celda "Importe" a la variable "total"
    if (row.cells[3].textContent == 'ANULADA')
    {
        var importe = (parseFloat(row.cells[4].textContent) * 0);
        row.cells[4].textContent = importe.toString(); // Actualizar el valor de la celda en la tabla
        var rowData = [
        row.cells[0].textContent,
        row.cells[1].textContent,
        row.cells[2].textContent,
        row.cells[3].textContent,
        row.cells[4].textContent];
        console.log(row.cells[4].textContent)
    }
    else
    {
        var importe = parseFloat(row.cells[4].textContent);
    }
    total += importe;
    rows.push(rowData);
  }

  // Agregar el total a la matriz "rows"
  var totalRow = ["", "", "", "Total:", (total.toFixed(2)).toString()];
  rows.push(totalRow);

  // Crear el PDF
  var doc = new jsPDF();

  // Agregar imagen en la esquina superior izquierda
  var img = new Image();
  img.onload = function () {
    doc.addImage(this, "JPEG", 14, 10, 27, 17);
    // Obtener la fecha y hora actual
    var fecha = new Date().toLocaleTimeString([], {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    // Agregar la fecha y hora en la esquina superior derecha
    doc.text(fecha, doc.internal.pageSize.width - 55.5, 10);

    // Convertir la posición en milímetros a puntos
    var mmToPt = 2.835;

    // Agregar el título centrado y en letra de tamaño 16 con un desplazamiento en el eje y
    doc.setFontSize(22);
    var title = "Lista de Ventas";
    var titleWidth =
      (doc.getStringUnitWidth(title) * doc.internal.getFontSize()) / mmToPt;
    var x = (doc.internal.pageSize.width - titleWidth) / 2;
    var y = 20;
    doc.text(title, x, y);

    // Agregar la tabla
    doc.autoTable({
      head: [
        ["Fecha", "Cliente", "Tipo de Pago", "Estado", "Importe"],
      ],
      body: rows,
      startY: 30, // Mover la tabla hacia abajo para evitar que cubra el título
      styles: { cell: { textAlign: 'center' } }
    });

    // Guardar el PDF
    doc.save("lista_ventas.pdf");
  };
  img.onerror = function () {
    console.error("La imagen no se pudo cargar.");
  };
  img.src = "static/img/1.jpeg";
}

document
  .getElementById("btnExportarVentas")
  .addEventListener("click", exportarPDF);
