function exportarPDF() {
  // Obtener los datos de la tabla
  var rows = [];
  var table = document.getElementById("dataTable");
  for (var i = 1, row; (row = table.rows[i]); i++) {
    var rowData = [
      row.cells[0].textContent,
      row.cells[1].textContent,
      row.cells[2].textContent,
      row.cells[3].textContent,
      row.cells[4].textContent,
    ];
    rows.push(rowData);
  }

  // Crear el PDF
  var doc = new jsPDF();

  // Agregar imagen en la esquina superior izquierda
  var img = new Image();
  img.onload = function () {
    doc.addImage(this, "JPEG", 14, 10, 27, 17);
    // Obtener la fecha y hora actual
    var fecha = new Date().toLocaleTimeString([], {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    // Agregar la fecha y hora en la esquina superior derecha
    doc.text(fecha, doc.internal.pageSize.width - 55.5, 10);

    // Convertir la posición en milímetros a puntos
    var mmToPt = 2.835;

    // Agregar el título centrado y en letra de tamaño 16 con un desplazamiento en el eje y
    doc.setFontSize(22);
    var title = "Lista de Proveedores";
    var titleWidth =
      (doc.getStringUnitWidth(title) * doc.internal.getFontSize()) / mmToPt;
    var x = (doc.internal.pageSize.width - titleWidth) / 2;
    var y = 20;
    doc.text(title, x, y);

    // Agregar la tabla
    doc.autoTable({
      head: [
        ["Proveedor", "N° Documento", "Correo Electrónico", "N° Teléfono", "Dirección"],
      ],
      body: rows,
      startY: 30, // Mover la tabla hacia abajo para evitar que cubra el título
      styles: { cell: { textAlign: 'center' } }
    });

    // Guardar el PDF
    doc.save("lista_proveedores.pdf");
  };
  img.onerror = function () {
    console.error("La imagen no se pudo cargar.");
  };
  img.src = "static/img/1.jpeg";
}

document
  .getElementById("btnExportarProveedores")
  .addEventListener("click", exportarPDF);
