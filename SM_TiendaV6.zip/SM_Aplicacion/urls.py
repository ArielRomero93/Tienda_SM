from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.inicio, name='inicio'),
    # REGISTRACION
    path('login_user/', views.login_user, name='login'),
    path('logout_user/', views.logout_user, name='logout'),
    path('register/', views.register, name='register'),
    path('perfiles/', views.lista_perfiles, name='lista_perfiles'),

    # CLIENTES
    path('clientes', views.clientes, name='clientes'),
    path('clientes/buscar/', views.buscar_clientes, name='buscar_clientes'),
    path('clientes/ver_cliente/<int:id>/', views.detalle_cliente, name='detalle_cliente'),
    path('clientes/crear', views.crear_cliente, name='crear_cliente'),
    path('clientes/editar/<int:id>/', views.editar_cliente, name='editar_cliente'),
    path('clienteeliminar/<int:id>', views.eliminar_cliente, name='eliminar_cliente'),

    # PROVEEDORES
    path('proveedores', views.proveedores, name='proveedores'),
    path('proveedores/ver_cliente/<int:id>/', views.detalle_proveedor, name='detalle_proveedor'),
    path('proveedores/crear', views.crear_proveedor, name='crear_proveedor'),
    path('proveedores/editar/<int:id>/', views.editar_proveedor, name='editar_proveedor'),
    path('proveedoreliminar/<int:id>', views.eliminar_proveedor, name='eliminar_proveedor'),

    # PRODUCTOS
    path('productos', views.productos, name='productos'),
    path('productos/crear/', views.crear_producto, name='crear_producto'),
    path('productos/<int:id>/', views.detalle_producto, name='detalle_producto'),
    path('productos/editar/<int:id>/', views.editar_producto, name='editar_producto'),
    path('productoseliminar/<int:id>/', views.eliminar_producto, name='eliminar_producto'),

    # VENTAS
    path('ventas', views.ventas, name='ventas'),
    path('ventas/crear/', views.crear_venta, name='crear_venta'),
    path('ventas/editar/<int:id>/', views.ventas_update, name='ventas_update'),
    path('anular_venta/<int:id>/', views.anular_venta, name='anular_venta'),
    path('ventas/comprobante/<int:id>/', views.generar_comprobanteVenta, name='generar_comprobanteVenta'),


    # COMPRAS
    path('compras', views.compras, name='compras'),
    path('compras/crear/', views.crear_compra, name='crear_compra'),
    path('compras/editar/<int:id>/', views.compras_update, name='compras_update'),
    path('cancelar_compra/<int:id>/', views.cancelar_compra, name='cancelar_compra'),
    path('compras/comprobante/<int:id>/', views.generar_comprobanteCompra, name='generar_comprobanteCompra'),

    # MOVIMIENTOS
    path('movimientos', views.movimientos, name='movimientos'),

    ]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)