from django.contrib.auth import authenticate, login, logout
from datetime import datetime, timedelta, date
from django.db import transaction
from django.db.models import Q, Max
from django.forms import inlineformset_factory, BaseFormSet
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import HttpResponse, Http404
from .models import Clientes, Proveedores, Productos, Ventas, VentaDetalle, Compras, CompraDetalle, PerfilesUsuarios, \
    MovimientosCaja
from .forms import ClientesForm, ClienteReadOnlyForm, ProveedoresForm, ProductosForm, VentasForm, VentaDetalleForm,ComprasForm, CompraDetalleForm ,UsuarioForm, PerfilesUsuariosForm, User
from django.urls import reverse
from django.db.models import Prefetch
from django.db import transaction
from io import BytesIO
from reportlab.pdfgen import canvas
import json

# Create your views here.
class SuccessMessageMixin:
    success_message = ''

    def form_valid(self, form):
        response = super().form_valid(form)
        success_message = self.get_success_message(form.cleaned_data)
        if success_message:
            messages.success(self.request, success_message)
        return response

    def get_success_message(self, cleaned_data):
        return self.success_message % cleaned_data


def bienvenidos(request):
    mensaje = f"<html><h1>Bienvenidos a Inmobiliaria Carena</h1> " \
              f"<p>Ya hay {Clientes.objects.count()} Clientes...<p></html>"
    return HttpResponse(mensaje)
def profile(request):
    return render(request, 'paginas/profile.html')


def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('inicio')
        else:
            messages.success(request, "Hubo un error, intente nuevamente" )
            return redirect('login')
    else:
        return render(request, 'registracion/login.html', {})


def logout_user(request):
     logout(request)
     messages.success(request,("Te deslogueaste...!"))
     return redirect('login')



# FUNCIONES AUXILIARES

def register(request):
    registered = False

    if request.method == 'POST':
        user_form = UsuarioForm(data=request.POST)
        profile_form = PerfilesUsuariosForm(data=request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user.password)
            user.save()

            profile = profile_form.save(commit=False)
            profile.usuario = user
            profile.save()

            registered = True

        else:
            print(user_form.errors, profile_form.errors)

    else:
        user_form = UsuarioForm()
        profile_form = PerfilesUsuariosForm()

    return render(request, 'registracion/register.html', {'user_form': user_form,
                                                           'profile_form': profile_form,
                                                           'registered': registered})

def lista_perfiles(request):
    perfiles = PerfilesUsuarios.objects.all()
    return render(request, 'registracion/lista_perfiles.html', {'perfiles': perfiles})

def inicio(request):
    return render(request, 'paginas/inicio.html')


# CLIENTES

def clientes(request):
    termino_busqueda = request.GET.get('termino_busqueda')
    clientes = Clientes.objects.order_by('nombre')
    if termino_busqueda:
        clientes = clientes.filter(
            Q(nombre__icontains=termino_busqueda) |  # Filtrar por nombre que contenga el término de búsqueda
            Q(numeroDocumento__icontains=termino_busqueda) |  # Filtrar por numero de Documento que contenga el término de búsqueda
            Q(email__icontains=termino_busqueda)  # Filtrar por email que contenga el término de búsqueda
        )
    return render(request, 'clientes/index.html', {'clientes': clientes, 'termino_busqueda': termino_busqueda})


def buscar_clientes(request):
    query = request.GET.get('q')
    if query is not None:
        clientes = Clientes.objects.filter(
            Q(nombre__icontains=query) |  # Filtrar por nombre que contenga el término de búsqueda
            Q(numeroDocumento__icontains=query) |  # Filtrar por numero de Documento que contenga el término de búsqueda
            Q(email__icontains=query)  # Filtrar por email que contenga el término de búsqueda
        )
    else:
        clientes = Clientes.objects.all()
    return render(request, 'clientes/index.html', {'clientes': clientes})


def detalle_cliente(request, id):
    cliente = get_object_or_404(Clientes, pk=id)
    context = {'cliente': cliente}
    return render(request, 'clientes/ver_cliente.html', context)


def crear_cliente(request):
    if request.method == 'POST':
        formulario = ClientesForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm()

    return render(request, 'clientes/crear.html', {'formulario': formulario})


def editar_cliente(request, id):
    cliente = Clientes.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ClientesForm(request.POST, instance=cliente)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm(instance=cliente)
    url = reverse('editar_cliente', kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'clientes/editar.html', {'formulario': formulario, 'url': url})


def eliminar_cliente(request, id):
    cliente = Clientes.objects.get(id=id)
    cliente.delete()
    return redirect('clientes')


# PROVEEDORES
def proveedores(request):
    proveedores = Proveedores.objects.order_by('nombre')
    return render(request, 'proveedores/index.html', {'proveedores': proveedores})


def detalle_proveedor(request, id):
    proveedor = get_object_or_404(Proveedores, pk=id)
    context = {'proveedor': proveedor}
    return render(request, 'proveedores/ver_proveedor.html', context)


def crear_proveedor(request):
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm()

    return render(request, 'proveedores/crear.html', {'formulario': formulario})


def editar_proveedor(request, id):
    proveedor = Proveedores.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST, instance=proveedor)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm(instance=proveedor)
    url = reverse('editar_proveedor',
                  kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'proveedores/editar.html', {'formulario': formulario, 'url': url})


def eliminar_proveedor(request, id):
    proveedor = Proveedores.objects.get(id=id)
    proveedor.delete()
    return redirect('proveedores')


# PRODUCTOS
def productos(request):
    productos = Productos.objects.all()
    return render(request, 'productos/index.html', {'productos': productos})


def detalle_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    costo_total = producto.precioCosto * producto.cantidad  # calcula el costo total del producto
    context = {
        'producto': producto,
        'costo_total': costo_total,
    }
    return render(request, 'productos/ver_producto.html', context)


def crear_producto(request):
    if request.method == 'POST':
        formulario = ProductosForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm()
    return render(request, 'productos/crear.html', {'formulario': formulario})


def editar_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    if request.method == 'POST':
        formulario = ProductosForm(request.POST, instance=producto)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm(instance=producto)
        url = reverse('editar_producto',
                      kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'productos/editar.html', {'formulario': formulario, 'url': url})


def eliminar_producto(request, id):
    producto = Productos.objects.get(id=id)
    producto.delete()
    return redirect('productos')


# VENTAS
def ventas(request):
    ventas = Ventas.objects.order_by('-fecha', '-id')
    clientes = Clientes.objects.all()

    # Procesar filtros
    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')
    cliente = request.GET.get('cliente')
    estado = request.GET.get('estado')
    tipo_pago = request.GET.get('tipoPago')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        ventas = ventas.filter(fecha__gte=fecha_desde)

    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        ventas = ventas.filter(fecha__lte=fecha_hasta)
    if cliente:
        ventas = ventas.filter(idCliente=cliente)
    if estado:
        ventas = ventas.filter(idEstado=estado)
    if tipo_pago:
        ventas = ventas.filter(idTipoPago=tipo_pago)

    # Obtener valores de estado y tipo_pago para mostrar en la plantilla
    estados = Ventas.ESTADO
    tipos_pago = Ventas.TIPOPAGO

    # Añadir valores por defecto de los filtros al contexto
    context = {
        'ventas': ventas,
        'clientes': clientes,
        'estados': estados,
        'tipos_pago': tipos_pago,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        'cliente_default': int(cliente) if cliente else None,  # Agregar el valor del cliente seleccionado al contexto
        'estado_default': estado,  # Agregar el valor del estado seleccionado al contexto
        'tipo_pago_default': tipo_pago,  # Agregar el valor del tipo de pago seleccionado al contexto
    }

    return render(request, 'ventas/index.html', context)


def crear_venta(request):
    venta = Ventas()  # crear objeto Vacio
    VentaDetalleFormset = inlineformset_factory(Ventas, VentaDetalle, form=VentaDetalleForm, extra=10, can_delete=True)
    if request.method == 'POST':
        ventas_form = VentasForm(request.POST, instance=venta)
        if ventas_form.is_valid():
            venta = ventas_form.save(commit=False)
            venta.save()
            venta_detalle_formset = VentaDetalleFormset(request.POST, instance=venta)
            for form in venta_detalle_formset:
                if not form.is_valid():
                    print("No hay producto")
                    continue
                else:
                    print("Hay producto")
                    producto = form.cleaned_data['idProducto']
                    cantidad_vendida = form.cleaned_data['cantidad']
                    producto.cantidad -= cantidad_vendida
                    producto.save()
                    form.instance.idVenta = venta
                    form.save()

            # Crear objeto MovimientosCaja para registrar la venta
            movimiento_venta = MovimientosCaja()
            movimiento_venta.fecha = venta.fecha
            movimiento_venta.concepto = "Venta realizada en " + venta.get_idTipoPago_display()
            movimiento_venta.ingresos = venta.precioTotal
            movimiento_venta.venta = venta
            movimiento_venta.egresos = 0

            # Obtener el último movimiento de caja registrado
            ultimo_movimiento = MovimientosCaja.objects.order_by('-fecha', '-id').first()

            # Si no hay ningún movimiento, el saldo actual es cero
            if ultimo_movimiento is None:
                saldo_anterior = 0
            # Sí hay al menos un movimiento, sumar el saldo con el ingreso y restar el egreso
            else:
                saldo_anterior = ultimo_movimiento.saldo
            print(saldo_anterior)
            print(movimiento_venta.ingresos)
            print(movimiento_venta.egresos)
            movimiento_venta.saldo = saldo_anterior + movimiento_venta.ingresos - movimiento_venta.egresos
            print(movimiento_venta.saldo)
            movimiento_venta.save()

            return redirect('ventas')
        else:
            print("Acá llega")
    else:
        ventas_form = VentasForm(instance=venta)
        venta_detalle_formset = VentaDetalleFormset(instance=venta)
    context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
    return render(request, 'ventas/crear.html', context)



def ventas_update(request, id):
    venta = get_object_or_404(Ventas, pk=id)
    totalVentaRecuperada = venta.precioTotal
    VentaDetalleFormset = inlineformset_factory(Ventas, VentaDetalle, form=VentaDetalleForm, extra=5, can_delete=True)
    if request.method == 'POST':
        ventas_form = VentasForm(request.POST, instance=venta)
        if ventas_form.is_valid():
            venta = ventas_form.save(commit=False)
            venta.save()
            venta_detalle_formset = VentaDetalleFormset(request.POST, instance=venta)
            venta_detalles = venta.ventadetalle_set.all()  # Obtener los detalles de venta actuales
            for form, venta_detalle in zip(venta_detalle_formset, venta_detalles):
                if not form.is_valid():
                    print("No hay producto")
                    continue
                else:
                    producto = form.cleaned_data['idProducto']
                    cantidad_antigua = venta_detalle.cantidad
                    cantidad_nueva = form.cleaned_data['cantidad']
                    cantidad_diferencia = cantidad_nueva - cantidad_antigua
                    producto.cantidad -= cantidad_diferencia  # Actualizar la cantidad disponible
                    producto.save()
                    form.instance.idVenta = venta
                    form.save()

            # Actualizar el saldo
            movimiento_venta = MovimientosCaja.objects.filter(fecha=venta.fecha).aggregate(Max('id'))
            if movimiento_venta['id__max'] is not None:
                saldo_anterior = MovimientosCaja.objects.get(id=movimiento_venta['id__max']).saldo
            else:
                saldo_anterior = 0

            ingresos = venta.precioTotal
            egresos = totalVentaRecuperada
            saldo_actual = saldo_anterior + ingresos - egresos

            movimiento_caja = MovimientosCaja.objects.create(fecha=venta.fecha, concepto="Edición de venta N° " + str(venta.id), ingresos=ingresos, egresos=egresos, saldo=saldo_actual, venta=venta)


            return redirect('ventas')
        else:
            # print(ventas_form.errors)
            print("Acá llega")
    else:
        ventas_form = VentasForm(instance=venta)
        venta_detalle_formset = VentaDetalleFormset(instance=venta)
    context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
    return render(request, 'ventas/crear.html', context)


def anular_venta(request, id):
    venta = get_object_or_404(Ventas, id=id)
    if venta.idEstado != Ventas.ANULADA:
        venta.idEstado = Ventas.ANULADA
        venta.save()
        detalles_venta = venta.ventadetalle_set.all()  # Obtener los detalles de venta correspondientes
        for detalle in detalles_venta:
            producto = detalle.idProducto
            cantidad_vendida = detalle.cantidad
            producto.cantidad += cantidad_vendida  # Actualizar la cantidad disponible
            producto.save()
        # Actualizar el saldo
        movimiento_venta = MovimientosCaja.objects.filter(fecha=venta.fecha).aggregate(Max('id'))
        if movimiento_venta['id__max'] is not None:
            saldo_anterior = MovimientosCaja.objects.get(id=movimiento_venta['id__max']).saldo
        else:
            saldo_anterior = 0

        ingresos = venta.precioTotal * -1
        egresos = 0
        saldo_actual = saldo_anterior + ingresos - egresos

        movimiento_caja = MovimientosCaja.objects.create(fecha=venta.fecha, concepto="Ajuste por anulación de venta N° " + str(venta.id),ingresos=ingresos, egresos=egresos, saldo=saldo_actual, venta=venta)
    else:
        print('Ya esta anulada CAPOEIRA')
    return redirect('ventas')


def generar_comprobanteVenta(request, id):
    venta = get_object_or_404(Ventas, pk=id)
    venta_detalle = VentaDetalle.objects.filter(idVenta=venta)

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)

    # Encabezado de la comprobante de venta
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(50, 750, 'Comprobante de Venta')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 725, 'Número de comprobante: {}'.format(venta.id))
    pdf.drawString(50, 710, 'Fecha de emisión: {}'.format(venta.fecha))
    pdf.drawString(50, 695, 'Cliente: {}'.format(venta.idCliente.nombre))

    # Detalle de la comprobate
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(50, 650, 'Detalle de la venta:')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 625, 'Producto')
    pdf.drawString(200, 625, 'Cantidad')
    pdf.drawString(300, 625, 'Precio unitario')
    pdf.drawString(425, 625, 'Total')

    y = 600
    for detalle in venta_detalle:
        pdf.drawString(50, y, detalle.idProducto.nombre)
        pdf.drawString(200, y, str(detalle.cantidad))
        pdf.drawString(300, y, '$ {}'.format(detalle.precioUnitario))
        pdf.drawString(425, y, '$ {}'.format(detalle.subTotal))
        y -= 25

    # Totales
    pdf.drawString(300, y - 25, 'Subtotal: $ {}'.format(venta.precioTotal))
    # pdf.drawString(300, y - 50, 'IVA: $ {}'.format(venta.iva))
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(300, y - 75, 'Total: $ {}'.format(venta.precioTotal))

    # Guardar y cerrar el PDF
    pdf.showPage()
    pdf.save()

    # Obtener el valor del buffer y crear la respuesta del PDF
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=comprobanteVenta_{}.pdf'.format(venta.id)

    return response

# COMPRAS
def compras(request):
    compras = Compras.objects.order_by('-fecha', '-id')
    proveedores = Proveedores.objects.all()

    # Procesar filtros
    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')
    proveedor = request.GET.get('proveedor')
    estado = request.GET.get('estado')
    tipo_pago = request.GET.get('tipoPago')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        compras = compras.filter(fecha__gte=fecha_desde)
    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        compras = compras.filter(fecha__lte=fecha_hasta)
    if proveedor:
        compras = compras.filter(idProveedor=proveedor)
    if estado:
        compras = compras.filter(idEstado=estado)
    if tipo_pago:
        compras = compras.filter(idTipoPago=tipo_pago)

    # Obtener valores de estado y tipo_pago para mostrar en la plantilla
    estados = Compras.ESTADO
    tipos_pago = Compras.TIPOPAGO

    context = {
        'compras': compras,
        'proveedores': proveedores,
        'estados': estados,
        'tipos_pago': tipos_pago,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        'proveedor_default': int(proveedor) if proveedor else None,  # Agregar el valor del cliente seleccionado al contexto
        'estado_default': estado,  # Agregar el valor del estado seleccionado al contexto
        'tipo_pago_default': tipo_pago,  # Agregar el valor del tipo de pago seleccionado al contexto
    }
    return render(request, 'compras/index.html', context)


def crear_compra(request):
    compra = Compras()  # crear objeto Vacio
    CompraDetalleFormset = inlineformset_factory(Compras, CompraDetalle, form=CompraDetalleForm, extra=10, can_delete=True)
    if request.method == 'POST':
        compras_form = ComprasForm(request.POST, instance=compra)
        if compras_form.is_valid():
            compra = compras_form.save(commit=False)
            compra.save()
            compra_detalle_formset = CompraDetalleFormset(request.POST, instance=compra)
            for form in compra_detalle_formset:
                if not form.is_valid():
                    print("No hay producto")
                    continue
                else:
                    producto = form.cleaned_data['idProducto']
                    cantidad_vendida = form.cleaned_data['cantidad']
                    producto.cantidad += cantidad_vendida
                    producto.save()
                    print("Hay producto")
                    form.instance.idCompra = compra
                    form.save()

            # Crear objeto MovimientosCaja para registrar la venta
            movimiento_compra = MovimientosCaja()
            movimiento_compra.fecha = compra.fecha
            movimiento_compra.concepto = "Compra realizada en " + compra.get_idTipoPago_display()
            movimiento_compra.ingresos = 0
            movimiento_compra.compra = compra
            movimiento_compra.egresos = compra.precioTotal

            # Obtener el último movimiento de caja registrado
            ultimo_movimiento = MovimientosCaja.objects.order_by('-fecha', '-id').first()

            # Si no hay ningún movimiento, el saldo actual es cero
            if ultimo_movimiento is None:
                saldo_anterior = 0
            # Sí hay al menos un movimiento, sumar el saldo con el ingreso y restar el egreso
            else:
                saldo_anterior = ultimo_movimiento.saldo
            print(saldo_anterior)
            print(movimiento_compra.ingresos)
            print(movimiento_compra.egresos)
            movimiento_compra.saldo = saldo_anterior + movimiento_compra.ingresos - movimiento_compra.egresos
            print(movimiento_compra.saldo)
            movimiento_compra.save()
            return redirect('compras')
        else:
            # print(ventas_form.errors)
            print("Acá llega")
    else:
        compras_form = ComprasForm(instance=compra)
        compra_detalle_formset = CompraDetalleFormset(instance=compra)
    context = {'compras_form': compras_form, 'compra_detalle_formset': compra_detalle_formset}
    return render(request, 'compras/crear.html', context)


def compras_update(request, id):
    compra = get_object_or_404(Compras, pk=id)
    totalCompraRecuperada = compra.precioTotal
    CompraDetalleFormset = inlineformset_factory(Compras, CompraDetalle, form=CompraDetalleForm, extra=5, can_delete=True)
    if request.method == 'POST':
        compras_form = ComprasForm(request.POST, instance=compra)
        if compras_form.is_valid():
            compra = compras_form.save(commit=False)
            compra.save()
            compra_detalle_formset = CompraDetalleFormset(request.POST, instance=compra)
            compra_detalles = compra.compradetalle_set.all()  # Obtener los detalles de compra actuales
            for form, compra_detalle in zip(compra_detalle_formset, compra_detalles):
                if not form.is_valid():
                    print("No hay producto")
                    continue
                else:
                    producto = form.cleaned_data['idProducto']
                    cantidad_antigua = compra_detalle.cantidad
                    cantidad_nueva = form.cleaned_data['cantidad']
                    cantidad_diferencia = cantidad_nueva - cantidad_antigua
                    producto.cantidad += cantidad_diferencia  # Actualizar la cantidad disponible
                    producto.save()
                    form.instance.idCompra = compra
                    form.save()

            # Actualizar el saldo
            movimiento_compra = MovimientosCaja.objects.filter(fecha=compra.fecha).aggregate(Max('id'))
            if movimiento_compra['id__max'] is not None:
                saldo_anterior = MovimientosCaja.objects.get(id=movimiento_compra['id__max']).saldo
            else:
                saldo_anterior = 0

            ingresos = totalCompraRecuperada
            egresos = compra.precioTotal
            saldo_actual = saldo_anterior + ingresos - egresos

            movimiento_caja = MovimientosCaja.objects.create(fecha=compra.fecha, concepto="Edición de compra N° " + str(compra.id), ingresos=ingresos, egresos=egresos, saldo=saldo_actual, compra=compra)

            return redirect('compras')
        else:
            print("Acá llega")
    else:
        compras_form = ComprasForm(instance=compra)
        compra_detalle_formset = CompraDetalleFormset(instance=compra)
    context = {'compras_form': compras_form, 'compra_detalle_formset': compra_detalle_formset}
    return render(request, 'compras/crear.html', context)


def cancelar_compra(request, id):
    compra = get_object_or_404(Compras, id=id)
    if compra.idEstado != Compras.CANCELADA:
        compra.idEstado = Compras.CANCELADA
        compra.save()
        detalles_compra = compra.compradetalle_set.all()  # Obtener los detalles de venta correspondientes
        for detalle in detalles_compra:
            producto = detalle.idProducto
            cantidad_vendida = detalle.cantidad
            producto.cantidad -= cantidad_vendida  # Actualizar la cantidad disponible
            producto.save()

        # Actualizar el saldo
        movimiento_compra = MovimientosCaja.objects.filter(fecha=compra.fecha).aggregate(Max('id'))
        if movimiento_compra['id__max'] is not None:
            saldo_anterior = MovimientosCaja.objects.get(id=movimiento_compra['id__max']).saldo
        else:
            saldo_anterior = 0
        ingresos = 0
        egresos = compra.precioTotal * -1
        saldo_actual = saldo_anterior + ingresos - egresos
        movimiento_caja = MovimientosCaja.objects.create(fecha=compra.fecha, concepto="Ajuste por cancelación de compra N° " + str(compra.id), ingresos=ingresos, egresos=egresos, saldo=saldo_actual, compra=compra)

    return redirect('compras')


def generar_comprobanteCompra(request, id):
    compra = get_object_or_404(Compras, pk=id)
    compra_detalle = CompraDetalle.objects.filter(idCompra=compra)

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)

    # Encabezado del comprobante de compra
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(50, 750, 'Comprobante de Compra')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 725, 'Número de comprobante: {}'.format(compra.id))
    pdf.drawString(50, 710, 'Fecha de emisión: {}'.format(compra.fecha))
    pdf.drawString(50, 695, 'proveedor: {}'.format(compra.idProveedor.nombre))

    # Detalle de la comprobate
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(50, 650, 'Detalle de la compra:')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 625, 'Producto')
    pdf.drawString(200, 625, 'Cantidad')
    pdf.drawString(300, 625, 'Precio unitario')
    pdf.drawString(425, 625, 'Total')

    y = 600
    for detalle in compra_detalle:
        pdf.drawString(50, y, detalle.idProducto.nombre)
        pdf.drawString(200, y, str(detalle.cantidad))
        pdf.drawString(300, y, '$ {}'.format(detalle.precioUnitario))
        pdf.drawString(425, y, '$ {}'.format(detalle.subTotal))
        y -= 25

    # Totales
    pdf.drawString(300, y - 25, 'Subtotal: $ {}'.format(compra.precioTotal))
    # pdf.drawString(300, y - 50, 'IVA: $ {}'.format(venta.iva))
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(300, y - 75, 'Total: $ {}'.format(compra.precioTotal))

    # Guardar y cerrar el PDF
    pdf.showPage()
    pdf.save()

    # Obtener el valor del buffer y crear la respuesta del PDF
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=comprobanteCompra_{}.pdf'.format(compra.id)

    return response


# MOVIMIENTOS

def movimientos(request):
    movimientos = MovimientosCaja.objects.order_by('-fecha', '-id')

    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        movimientos = movimientos.filter(fecha__gte=fecha_desde)
    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        movimientos = movimientos.filter(fecha__lte=fecha_hasta)

    # Añadir valores por defecto de los filtros al contexto
    context = {
        'movimientos': movimientos,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        }

    return render(request, 'movimientos/index.html', context)