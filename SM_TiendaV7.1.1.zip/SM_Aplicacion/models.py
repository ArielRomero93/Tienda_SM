from django.db import models
from django.contrib.auth.models import User
from time import timezone

from django.db.models import Sum
from django.urls import reverse


# Create your models here.

# Perfiles
class PerfilesUsuarios(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    # Agrega campos adicionales para el perfil de usuario
    bio = models.TextField(max_length=500, blank=True)
    numeroDocumento = models.CharField(max_length=13, blank=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=200, blank=True)


# Clientes
class Clientes(models.Model):
    nombre = models.CharField(max_length=200, verbose_name='Nombre')
    numeroDocumento = models.CharField(max_length=13, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    eliminado = models.BooleanField(default=False)

    def __str__(self):
        return self.nombre


# Proveedores
class Proveedores(models.Model):
    nombre = models.CharField(max_length=200, verbose_name='Nombre')
    numeroDocumento = models.CharField(max_length=13, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    eliminado = models.BooleanField(default=False)
    def __str__(self):
        return self.nombre


# Productos
class Productos(models.Model):
    CATEGORIAS = (
        ('Indumentaria', 'Indumentaria'),
        ('Accesorios', 'Accesorios'),
        ('Calzado', 'Calzado'),
        ('CalzadoNinio', 'Calzado Niño'),
    )
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    categoria = models.CharField(choices=CATEGORIAS, verbose_name='Categoria', max_length=20)
    precioCosto = models.DecimalField(max_digits=8, decimal_places=2, blank=True)
    cantidad = models.IntegerField(default=0)
    eliminado = models.BooleanField(default=True)

    def __str__(self):
        return self.nombre


# Ventas
class Ventas(models.Model):
    EFECTIVO = 'EF'
    TARJETACREDITO = 'TC'
    TARJETADEBITO = 'TD'
    CUENTACORRIENTE = 'CC'
    TRANSFERENCIA = 'TR'
    TIPOPAGO = [
        (EFECTIVO, 'Efectivo'),
        (TARJETACREDITO, 'Tarjeta de Credito'),
        (TARJETADEBITO, 'Tarjeta de Debito'),
        (CUENTACORRIENTE, 'Cuenta Corriente'),
        (TRANSFERENCIA, 'Transferencia')
    ]

    FINALIZADA = 'FI'
    ANULADA = 'AN'

    ESTADO = [
        (FINALIZADA, 'FINALIZADA'),
        (ANULADA, 'ANULADA')
    ]
    fecha = models.DateField()
    idCliente = models.ForeignKey(Clientes, on_delete=models.CASCADE)
    idTipoPago = models.CharField(choices=TIPOPAGO, max_length= 3, default=EFECTIVO)
    idEstado = models.CharField(choices=ESTADO, max_length= 3, default=FINALIZADA)
    precioTotal = models.DecimalField(max_digits=10, decimal_places=2)


class VentaDetalle(models.Model):
    idVenta = models.ForeignKey(Ventas, on_delete=models.CASCADE)
    idProducto = models.ForeignKey(Productos, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precioUnitario = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    subTotal = models.DecimalField(max_digits=10, decimal_places=2)


# Compras
class Compras(models.Model):
    EFECTIVO = 'EF'
    TARJETACREDITO = 'TC'
    TARJETADEBITO = 'TD'
    CUENTACORRIENTE = 'CC'
    TRANSFERENCIA = 'TR'
    TIPOPAGO = [
        (EFECTIVO, 'Efectivo'),
        (TARJETACREDITO, 'Tarjeta de Credito'),
        (TARJETADEBITO, 'Tarjeta de Debito'),
        (CUENTACORRIENTE, 'Cuenta Corriente'),
        (TRANSFERENCIA, 'Transferencia')
    ]

    ENTREGADA = 'EN'
    VIAJANDO = 'VI'
    CANCELADA = 'CA'
    ESTADO = [
        (ENTREGADA, 'ENTREGADA'),
        (VIAJANDO, 'VIAJANDO'),
        (CANCELADA, 'CANCELADA')
    ]
    fecha = models.DateField()
    idProveedor = models.ForeignKey(Proveedores, on_delete=models.PROTECT)
    idTipoPago = models.CharField(choices=TIPOPAGO, max_length= 3, default=EFECTIVO)
    idEstado = models.CharField(choices=ESTADO, max_length= 3, default=ENTREGADA)
    precioTotal = models.DecimalField(max_digits=10, decimal_places=2)


class CompraDetalle(models.Model):
    idCompra = models.ForeignKey(Compras, on_delete=models.CASCADE)
    idProducto = models.ForeignKey(Productos, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precioUnitario = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    subTotal = models.DecimalField(max_digits=10, decimal_places=2)


# Movimientos Caja
class MovimientosCaja(models.Model):
    fecha = models.DateField()
    concepto = models.CharField(max_length=255)
    ingresos = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    egresos = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    saldo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    venta = models.ForeignKey(Ventas, on_delete=models.CASCADE, blank=True, null=True)
    compra = models.ForeignKey(Compras, on_delete=models.CASCADE, blank=True, null=True)


# Tareas

class Tareas(models.Model):
    fechaCreacion = models.DateField(auto_now_add=True)
    fechaRealizacion = models.DateField(blank=True, null=True)
    tarea = models.CharField(max_length=255)
    realizada = models.BooleanField(default=False)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)