from django.contrib.auth import authenticate, login, logout
from datetime import datetime, timedelta, date

from django.contrib.auth.decorators import login_required
from django.db.models import Q, Max
from django.utils import timezone
from django.forms import inlineformset_factory
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import HttpResponse, Http404
from .models import Clientes, Proveedores, Productos, Ventas, VentaDetalle, Compras, CompraDetalle, PerfilesUsuarios, \
    MovimientosCaja, Tareas
from .forms import ClientesForm, ProveedoresForm, ProductosForm, VentasForm, VentaDetalleForm,ComprasForm, CompraDetalleForm ,UsuarioForm, PerfilesUsuariosForm, User, TareasForm
from django.urls import reverse
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

# Create your views here.
class SuccessMessageMixin:
    success_message = ''

    def form_valid(self, form):
        response = super().form_valid(form)
        success_message = self.get_success_message(form.cleaned_data)
        if success_message:
            messages.success(self.request, success_message)
        return response

    def get_success_message(self, cleaned_data):
        return self.success_message % cleaned_data

# def profile(request):
#     return render(request, 'paginas/profile.html')

@login_required
def profile(request):
    perfil_usuario = PerfilesUsuarios.objects.filter(usuario=request.user).first()
    return render(request, 'registracion/ver_perfil.html', {'perfil_usuario': perfil_usuario})

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('inicio')
        else:
            try:
                user = User.objects.get(username=username)
                messages.error(request, "Contraseña incorrecta")
            except User.DoesNotExist:
                messages.error(request, "Usuario incorrecto")
            return redirect('login')
    else:
        return render(request, 'registracion/login.html', {})


def logout_user(request):
     logout(request)
     return redirect('login')



#REGISTRACION

def register(request):
    registered = False

    if request.method == 'POST':
        user_form = UsuarioForm(data=request.POST)
        profile_form = PerfilesUsuariosForm(data=request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user.password)
            user.save()

            profile = profile_form.save(commit=False)
            profile.usuario = user
            profile.save()

            registered = True

        else:
            print(user_form.errors, profile_form.errors)

    else:
        user_form = UsuarioForm()
        profile_form = PerfilesUsuariosForm()

    return render(request, 'registracion/register.html', {'user_form': user_form,
                                                           'profile_form': profile_form,
                                                           'registered': registered})

def lista_perfiles(request):
    perfiles = PerfilesUsuarios.objects.all().order_by('usuario__username')
    return render(request, 'registracion/lista_perfiles.html', {'perfiles': perfiles})

def inicio(request):
    return render(request, 'paginas/inicio.html')


# CLIENTES

def clientes(request):
    clientes = Clientes.objects.exclude(eliminado=True).order_by('nombre')

    return render(request, 'clientes/index.html', {'clientes': clientes})

def detalle_cliente(request, id):
    cliente = get_object_or_404(Clientes, pk=id)
    context = {'cliente': cliente}
    return render(request, 'clientes/ver_cliente.html', context)


def crear_cliente(request):
    if request.method == 'POST':
        formulario = ClientesForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm()

    return render(request, 'clientes/crear.html', {'formulario': formulario})


def editar_cliente(request, id):
    cliente = Clientes.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ClientesForm(request.POST, instance=cliente)
        if formulario.is_valid():
            formulario.save()
            return redirect('clientes')
    else:
        formulario = ClientesForm(instance=cliente)
    url = reverse('editar_cliente', kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'clientes/editar.html', {'formulario': formulario, 'url': url})


def eliminar_cliente(request, id):
    cliente = Clientes.objects.get(id=id)
    cliente.eliminado = True
    cliente.save()
    return redirect('clientes')


# PROVEEDORES
def proveedores(request):
    proveedores = Proveedores.objects.exclude(eliminado=True).order_by('nombre')

    return render(request, 'proveedores/index.html', {'proveedores': proveedores})


def detalle_proveedor(request, id):
    proveedor = get_object_or_404(Proveedores, pk=id)
    context = {'proveedor': proveedor}
    return render(request, 'proveedores/ver_proveedor.html', context)


def crear_proveedor(request):
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm()

    return render(request, 'proveedores/crear.html', {'formulario': formulario})


def editar_proveedor(request, id):
    proveedor = Proveedores.objects.get(pk=id)
    if request.method == 'POST':
        formulario = ProveedoresForm(request.POST, instance=proveedor)
        if formulario.is_valid():
            formulario.save()
            return redirect('proveedores')
    else:
        formulario = ProveedoresForm(instance=proveedor)
    url = reverse('editar_proveedor',
                  kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'proveedores/editar.html', {'formulario': formulario, 'url': url})


def eliminar_proveedor(request, id):
    proveedor = Proveedores.objects.get(id=id)
    proveedor.eliminado = True
    proveedor.save()
    return redirect('proveedores')


# PRODUCTOS
def productos(request):
    productos = Productos.objects.exclude(eliminado=True).order_by('nombre')
    return render(request, 'productos/index.html', {'productos': productos})


def productos_bajo_stock(request):
    productos = Productos.objects.filter(cantidad__lte=20).exclude(eliminado=True)
    return render(request, 'paginas/notificaciones.html', {'productos_bajos': productos})


def detalle_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    costo_total = producto.precioCosto * producto.cantidad  # calcula el costo total del producto
    context = {
        'producto': producto,
        'costo_total': costo_total,
    }
    return render(request, 'productos/ver_producto.html', context)


def crear_producto(request):
    if request.method == 'POST':
        formulario = ProductosForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm()
    return render(request, 'productos/crear.html', {'formulario': formulario})


def editar_producto(request, id):
    producto = get_object_or_404(Productos, pk=id)
    if request.method == 'POST':
        formulario = ProductosForm(request.POST, instance=producto)
        if formulario.is_valid():
            formulario.save()
            return redirect('productos')
    else:
        formulario = ProductosForm(instance=producto)
        url = reverse('editar_producto', kwargs={'id': id})  # asegurarse que el argumento 'id' se está pasando correctamente
    return render(request, 'productos/editar.html', {'formulario': formulario, 'url': url})


def eliminar_producto(request, id):
    producto = Productos.objects.get(id=id)
    producto.eliminado = True
    producto.save()
    return redirect('productos')


# VENTAS
def ventas(request):
    ventas = Ventas.objects.order_by('-fecha', '-id')
    clientes = Clientes.objects.filter(eliminado=False).order_by('nombre')

    # Procesar filtros
    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')
    cliente = request.GET.get('cliente')
    estado = request.GET.get('estado')
    tipo_pago = request.GET.get('tipoPago')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        ventas = ventas.filter(fecha__gte=fecha_desde)
    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        ventas = ventas.filter(fecha__lte=fecha_hasta)
    if cliente:
        ventas = ventas.filter(idCliente=cliente)
    if estado:
        ventas = ventas.filter(idEstado=estado)
    if tipo_pago:
        ventas = ventas.filter(idTipoPago=tipo_pago)

    # Obtener valores de estado y tipo_pago para mostrar en la plantilla
    estados = Ventas.ESTADO
    tipos_pago = Ventas.TIPOPAGO

    # Añadir valores por defecto de los filtros al contexto
    context = {
        'ventas': ventas,
        'clientes': clientes,
        'estados': estados,
        'tipos_pago': tipos_pago,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        'cliente_default': int(cliente) if cliente else None,  # Agregar el valor del cliente seleccionado al contexto
        'estado_default': estado,  # Agregar el valor del estado seleccionado al contexto
        'tipo_pago_default': tipo_pago,  # Agregar el valor del tipo de pago seleccionado al contexto
    }

    return render(request, 'ventas/index.html', context)


def crear_venta(request):
    venta = Ventas()  # crear objeto Vacio
    VentaDetalleFormset = inlineformset_factory(Ventas, VentaDetalle, form=VentaDetalleForm, extra=10, can_delete=True)
    if request.method == 'POST':
        ventas_form = VentasForm(request.POST, instance=venta)
        if ventas_form.is_valid():
            venta = ventas_form.save(commit=False)
            venta.save()
            venta_detalle_formset = VentaDetalleFormset(request.POST, instance=venta)
            for form in venta_detalle_formset:
                if not form.is_valid():
                    continue
                else:
                    producto = form.cleaned_data['idProducto']
                    cantidad_vendida = form.cleaned_data['cantidad']
                    producto.cantidad -= cantidad_vendida
                    producto.save()
                    form.instance.idVenta = venta
                    form.save()

            # Crear objeto MovimientosCaja para registrar la venta
            movimiento_venta = MovimientosCaja()
            movimiento_venta.fecha = venta.fecha
            movimiento_venta.concepto = "Venta realizada en " + venta.get_idTipoPago_display()
            movimiento_venta.ingresos = venta.precioTotal
            movimiento_venta.venta = venta
            movimiento_venta.egresos = 0

            # Obtener el último movimiento de caja registrado
            ultimo_movimiento = MovimientosCaja.objects.order_by('-fecha', '-id').first()

            # Si no hay ningún movimiento, el saldo actual es cero
            if ultimo_movimiento is None:
                saldo_anterior = 0
            # Sí hay al menos un movimiento, sumar el saldo con el ingreso y restar el egreso
            else:
                saldo_anterior = ultimo_movimiento.saldo
                movimiento_venta.saldo = saldo_anterior + movimiento_venta.ingresos - movimiento_venta.egresos

            return redirect('ventas')
        else:
            print("Venta no realizada")
    else:
        ventas_form = VentasForm(instance=venta)
        venta_detalle_formset = VentaDetalleFormset(instance=venta)
        for form in venta_detalle_formset:
            form.fields['idProducto'].queryset = Productos.objects.filter(eliminado=False)
    context = {'ventas_form': ventas_form, 'venta_detalle_formset': venta_detalle_formset}
    return render(request, 'ventas/crear.html', context)

def detalle_venta(request, id):
    venta = get_object_or_404(Ventas, pk=id)
    detalles_venta = VentaDetalle.objects.filter(idVenta=venta)

    # Agregar los detalles de la venta al contexto
    context = {'venta': venta, 'venta_detalle': detalles_venta}
    return render(request, 'ventas/ver_venta.html', context)

def anular_venta(request, id):
    venta = get_object_or_404(Ventas, id=id)
    if venta.idEstado != Ventas.ANULADA:
        venta.idEstado = Ventas.ANULADA
        venta.save()
        detalles_venta = venta.ventadetalle_set.all()  # Obtener los detalles de venta correspondientes
        for detalle in detalles_venta:
            producto = detalle.idProducto
            cantidad_vendida = detalle.cantidad
            producto.cantidad += cantidad_vendida  # Actualizar la cantidad disponible
            producto.save()
        # Actualizar el saldo
        movimiento_venta = MovimientosCaja.objects.filter(fecha=venta.fecha).aggregate(Max('id'))
        if movimiento_venta['id__max'] is not None:
            saldo_anterior = MovimientosCaja.objects.get(id=movimiento_venta['id__max']).saldo
        else:
            saldo_anterior = 0

        ingresos = venta.precioTotal * -1
        egresos = 0
        saldo_actual = saldo_anterior + ingresos - egresos

        movimiento_caja = MovimientosCaja.objects.create(fecha=venta.fecha, concepto="Ajuste por anulación de venta N° " + str(venta.id),ingresos=ingresos, egresos=egresos, saldo=saldo_actual, venta=venta)
    else:
        print('Ya esta anulada CAPOEIRA')
    return redirect('ventas')


def generar_comprobanteVenta(request, id):
    venta = get_object_or_404(Ventas, pk=id)
    venta_detalle = VentaDetalle.objects.filter(idVenta=venta)

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)
    logo_imagen = ImageReader('http://localhost:8000/static/img/LogoReporte.jpeg')

    # Dibujar la imagen en la posición deseada
    pdf.drawImage(logo_imagen, x=419, y=700, width=150, height=100)

    # Encabezado del comprobante de venta
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(50, 780, 'Comprobante de Venta')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 755, 'Número de comprobante: {}'.format(venta.id))
    pdf.drawString(50, 740, 'Fecha de emisión: {}'.format(venta.fecha))
    pdf.drawString(50, 725, 'Cliente: {}'.format(venta.idCliente.nombre))
    pdf.drawString(50, 710, 'Dirección: Av.San Martín 1590, Mina Clavero, Córdoba')
    h = 695
    pdf.drawString(50, h - 10, '-' * 127)
    # Detalle de la comprobate
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(50, 650, 'Detalle de la venta:')

    # Agregar una grilla para la sección de detalle
    pdf.drawString(50, 630, '-'*109)
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 615, 'Producto')
    pdf.drawString(295, 615, 'Cantidad')
    pdf.drawString(395, 615, 'Precio unitario')
    pdf.drawString(495, 615, 'SubTotales')
    pdf.drawString(50, 600, '-'*127)

    y = 585
    for detalle in venta_detalle:
        pdf.drawString(50, y, detalle.idProducto.nombre)
        pdf.drawString(315, y, str(detalle.cantidad))
        pdf.drawString(395, y, '$ {}'.format(detalle.precioUnitario))
        pdf.drawString(495, y, '$ {}'.format(detalle.subTotal))
        y -= 25

    pdf.drawString(50, y - 10, '-' * 127)
    # Grilla para el total
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(445, y - 65, 'Total: $ {}'.format(venta.precioTotal))

    # Guardar y cerrar el PDF
    pdf.showPage()
    pdf.save()

    # Obtener el valor del buffer y crear la respuesta del PDF
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=comprobanteVenta_{}.pdf'.format(venta.id)

    return response


# COMPRAS
def compras(request):
    compras = Compras.objects.order_by('-fecha', '-id')
    proveedores = Proveedores.objects.filter(eliminado=False).order_by('nombre')

    # Procesar filtros
    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')
    proveedor = request.GET.get('proveedor')
    estado = request.GET.get('estado')
    tipo_pago = request.GET.get('tipoPago')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        compras = compras.filter(fecha__gte=fecha_desde)
    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        compras = compras.filter(fecha__lte=fecha_hasta)
    if proveedor:
        compras = compras.filter(idProveedor=proveedor, idProveedor__eliminado=False)
    if estado:
        compras = compras.filter(idEstado=estado)
    if tipo_pago:
        compras = compras.filter(idTipoPago=tipo_pago)

    # Obtener valores de estado y tipo_pago para mostrar en la plantilla
    estados = Compras.ESTADO
    tipos_pago = Compras.TIPOPAGO

    context = {
        'compras': compras,
        'proveedores': proveedores,
        'estados': estados,
        'tipos_pago': tipos_pago,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        'proveedor_default': int(proveedor) if proveedor else None,  # Agregar el valor del cliente seleccionado al contexto
        'estado_default': estado,  # Agregar el valor del estado seleccionado al contexto
        'tipo_pago_default': tipo_pago,  # Agregar el valor del tipo de pago seleccionado al contexto
    }
    return render(request, 'compras/index.html', context)

def detalle_compra(request, id):
    compra = get_object_or_404(Compras, pk=id)
    detalles_compra = CompraDetalle.objects.filter(idCompra=compra)
    context = {'compra': compra, 'compra_detalle': detalles_compra}
    return render(request, 'compras/ver_compra.html', context)

def crear_compra(request):
    compra = Compras()  # crear objeto Vacio
    CompraDetalleFormset = inlineformset_factory(Compras, CompraDetalle, form=CompraDetalleForm, extra=10, can_delete=True)
    if request.method == 'POST':
        compras_form = ComprasForm(request.POST, instance=compra)
        if compras_form.is_valid():
            compra = compras_form.save(commit=False)
            compra.save()
            compra_detalle_formset = CompraDetalleFormset(request.POST, instance=compra)
            for form in compra_detalle_formset:
                if not form.is_valid():
                    continue
                else:
                    producto = form.cleaned_data['idProducto']
                    cantidad_comprada = form.cleaned_data['cantidad']
                    precio_costo = form.cleaned_data['precioUnitario']
                    producto.cantidad += cantidad_comprada
                    producto.precioCosto = precio_costo
                    producto.save()
                    form.instance.idCompra = compra
                    form.save()

            # Crear objeto MovimientosCaja para registrar la venta
            movimiento_compra = MovimientosCaja()
            movimiento_compra.fecha = compra.fecha
            movimiento_compra.concepto = "Compra realizada en " + compra.get_idTipoPago_display()
            movimiento_compra.ingresos = 0
            movimiento_compra.compra = compra
            movimiento_compra.egresos = compra.precioTotal

            # Obtener el último movimiento de caja registrado
            ultimo_movimiento = MovimientosCaja.objects.order_by('-fecha', '-id').first()

            # Si no hay ningún movimiento, el saldo actual es cero
            if ultimo_movimiento is None:
                saldo_anterior = 0
            # Sí hay al menos un movimiento, sumar el saldo con el ingreso y restar el egreso
            else:
                saldo_anterior = ultimo_movimiento.saldo
                movimiento_compra.saldo = saldo_anterior + movimiento_compra.ingresos - movimiento_compra.egresos
                movimiento_compra.save()
            return redirect('compras')
        else:
            print("compra no realizada")
    else:
        compras_form = ComprasForm(instance=compra)
        compras_form.fields['idProveedor'].queryset = Proveedores.objects.filter(eliminado=False) # se filtran los proveedores que no están eliminados
        compra_detalle_formset = CompraDetalleFormset(instance=compra)
        for form in compra_detalle_formset:
            form.fields['idProducto'].queryset = Productos.objects.filter(eliminado=False)
    context = {'compras_form': compras_form, 'compra_detalle_formset': compra_detalle_formset}
    return render(request, 'compras/crear.html', context)

def cancelar_compra(request, id):
    compra = get_object_or_404(Compras, id=id)
    if compra.idEstado != Compras.CANCELADA:
        compra.idEstado = Compras.CANCELADA
        compra.save()
        detalles_compra = compra.compradetalle_set.all()  # Obtener los detalles de venta correspondientes
        for detalle in detalles_compra:
            producto = detalle.idProducto
            cantidad_vendida = detalle.cantidad
            producto.cantidad -= cantidad_vendida  # Actualizar la cantidad disponible
            producto.save()

        # Actualizar el saldo
        movimiento_compra = MovimientosCaja.objects.filter(fecha=compra.fecha).aggregate(Max('id'))
        if movimiento_compra['id__max'] is not None:
            saldo_anterior = MovimientosCaja.objects.get(id=movimiento_compra['id__max']).saldo
        else:
            saldo_anterior = 0
        ingresos = 0
        egresos = compra.precioTotal * -1
        saldo_actual = saldo_anterior + ingresos - egresos
        movimiento_caja = MovimientosCaja.objects.create(fecha=compra.fecha, concepto="Ajuste por cancelación de compra N° " + str(compra.id), ingresos=ingresos, egresos=egresos, saldo=saldo_actual, compra=compra)

    return redirect('compras')


def generar_comprobanteCompra(request, id):
    compra = get_object_or_404(Compras, pk=id)
    compra_detalle = CompraDetalle.objects.filter(idCompra=compra)

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)
    logo_imagen = ImageReader('http://localhost:8000/static/img/LogoReporte.jpeg')

    # Dibujar la imagen en la posición deseada
    pdf.drawImage(logo_imagen, x=419, y=700, width=150, height=100)

    # Encabezado del comprobante de venta
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(50, 780, 'Comprobante de Compra')
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 755, 'Número de comprobante: {}'.format(compra.id))
    pdf.drawString(50, 740, 'Fecha de emisión: {}'.format(compra.fecha))
    pdf.drawString(50, 725, 'Proveedor: {}'.format(compra.idProveedor.nombre))
    pdf.drawString(50, 710, 'Dirección del Proveedor:  {}'.format(compra.idProveedor.direccion))
    h = 695
    pdf.drawString(50, h - 10, '-' * 127)
    # Detalle de la comprobate
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(50, 650, 'Detalle de la pedido:')

    # Agregar una grilla para la sección de detalle
    pdf.drawString(50, 630, '-'*109)
    pdf.setFont('Helvetica', 12)
    pdf.drawString(50, 615, 'Producto')
    pdf.drawString(295, 615, 'Cantidad')
    pdf.drawString(395, 615, 'Precio unitario')
    pdf.drawString(495, 615, 'SubTotales')
    pdf.drawString(50, 600, '-'*127)

    y = 585
    for detalle in compra_detalle:
        pdf.drawString(50, y, detalle.idProducto.nombre)
        pdf.drawString(315, y, str(detalle.cantidad))
        pdf.drawString(395, y, '$ {}'.format(detalle.precioUnitario))
        pdf.drawString(495, y, '$ {}'.format(detalle.subTotal))
        y -= 25

    pdf.drawString(50, y - 10, '-' * 127)
    # Grilla para el total
    pdf.setFont('Helvetica-Bold', 14)
    pdf.drawString(445, y - 65, 'Total: $ {}'.format(compra.precioTotal))

    # Guardar y cerrar el PDF
    pdf.showPage()
    pdf.save()

    # Obtener el valor del buffer y crear la respuesta del PDF
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename=comprobanteCompra_{}.pdf'.format(compra.id)

    return response


# MOVIMIENTOS
def movimientos(request):
    movimientos = MovimientosCaja.objects.order_by('-fecha', '-id')

    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')

    # Si no hay valor para fechaDesde, restar 2 días a la fecha actual
    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        movimientos = movimientos.filter(fecha__gte=fecha_desde)
    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        movimientos = movimientos.filter(fecha__lte=fecha_hasta)

    # Añadir valores por defecto de los filtros al contexto
    context = {
        'movimientos': movimientos,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
        }

    return render(request, 'movimientos/index.html', context)

# Tareas
def tareas(request):
    tareas = Tareas.objects.order_by('-fechaCreacion', '-id')
    fecha_desde = request.GET.get('fechaDesde')
    fecha_hasta = request.GET.get('fechaHasta')

    if not fecha_desde:
        fecha_desde = (datetime.now() - timedelta(days=2)).strftime('%Y-%m-%d')
    if fecha_desde:
        tareas = tareas.filter(fechaCreacion__gte=fecha_desde)

    if not fecha_hasta:
        fecha_hasta = date.today().strftime('%Y-%m-%d')
    if fecha_hasta:
        tareas = tareas.filter(fechaCreacion__lte=fecha_hasta)

    context = {
        'tareas': tareas,
        'fecha_desde_default': fecha_desde,  # Pasar la fecha desde predeterminada a la plantilla
        'fecha_hasta_default': fecha_hasta,
    }
    return render(request, 'tareas/index.html', context)


def crear_tarea(request):
    if request.method == 'POST':
        formulario = TareasForm(request.POST, user=request.user)
        if formulario.is_valid():
            tarea = formulario.save(commit=False)
            tarea.fechaCreacion = timezone.now().date()
            tarea.usuario = request.user
            tarea.save()
            return redirect('tareas')
    else:
        formulario = TareasForm(user=request.user)
    return render(request, 'tareas/crear.html', {'formulario': formulario})

def marcar_tarea_realizada(request, id):
    tarea = get_object_or_404(Tareas, id=id)
    tarea.realizada = True
    tarea.fechaRealizacion = timezone.now().date()
    tarea.save()
    return redirect('tareas')