from django import forms
from django.contrib.auth.models import User
from django.forms import inlineformset_factory
from .models import PerfilesUsuarios,Clientes, Proveedores, Productos, Ventas, VentaDetalle, Compras, CompraDetalle, Tareas




class UsuarioForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'email', 'password')

class PerfilesUsuariosForm(forms.ModelForm):
    class Meta:
        model = PerfilesUsuarios
        fields = ('bio', 'numeroDocumento', 'telefono', 'direccion')

class ClienteReadOnlyForm(forms.ModelForm):
    class Meta:
        model = Clientes
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'readonly': True}),
            'numeroDocumento': forms.TextInput(attrs={'readonly': True}),
            'email': forms.EmailInput(attrs={'readonly': True}),
            'telefono': forms.TextInput(attrs={'readonly': True}),
            'direccion': forms.TextInput(attrs={'readonly': True})
        }


class ClientesForm(forms.ModelForm):
    class Meta:
        model = Clientes
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'numeroDocumento': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'})
        }


class ProveedoresForm(forms.ModelForm):
    class Meta:
        model = Proveedores
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'numeroDocumento': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'})
        }


class ProductosForm(forms.ModelForm):
    class Meta:
        model = Productos
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
            'categoria': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precioCosto': forms.NumberInput(attrs={'class': 'form-control'})
        }

class VentasForm(forms.ModelForm):
    class Meta:
        model = Ventas
        fields = "__all__"
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'idCliente': forms.Select(attrs={'class': 'form-control'}),
            'idEstado': forms.Select(attrs={'class': 'form-control'}),
            'idTipoPago': forms.Select(attrs={'class': 'form-control'}),
            'precioTotal': forms.NumberInput(attrs={'class': 'form-control'})
        }
        labels = {
            'idCliente': 'Cliente'
        }

class VentaDetalleForm(forms.ModelForm):
    class Meta:
        model = VentaDetalle
        fields = "__all__"
        widgets = {
            'idProducto': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precioUnitario': forms.NumberInput(attrs={'class': 'form-control'}),
            'subTotal': forms.NumberInput(attrs={'class': 'form-control', 'readonly': 'readonly'})

        }
        labels = {
            'idProducto': 'Producto'
        }



class ComprasForm(forms.ModelForm):
    class Meta:
        model = Compras
        fields = "__all__"
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'idProveedor': forms.Select(attrs={'class': 'form-control'}),
            'idEstado': forms.Select(attrs={'class': 'form-control'}),
            'idTipoPago': forms.Select(attrs={'class': 'form-control'}),
            'precioTotal': forms.NumberInput(attrs={'class': 'form-control', 'readonly': 'readonly'})
        }
        labels = {
            'idProveedor': 'Proveedor'
        }

class CompraDetalleForm(forms.ModelForm):
    class Meta:
        model = CompraDetalle
        fields = "__all__"
        widgets = {
            'idProducto': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precioUnitario': forms.NumberInput(attrs={'class': 'form-control'}),
            'subTotal': forms.NumberInput(attrs={'class': 'form-control', 'readonly': 'readonly'})
        }
        labels = {
            'idProducto': 'Producto'
        }
        
#tareas

class TareasForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

    class Meta:
        model = Tareas
        fields = ['tarea', 'realizada']
        widgets = {
            'tarea': forms.TextInput(attrs={'class': 'form-control'}),
        }