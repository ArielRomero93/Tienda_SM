function exportarPDF() {
  // Obtener los datos de la tabla
  var rows = [];
  var table = document.getElementById("dataTable");
  console.log(table.rows.length);
  if (table.rows.length <= 1) {
    alert("La grilla no contiene datos que exportar");
    return;
  }
  var total = 0;
  for (var i = 1, row; (row = table.rows[i]); i++) {
    var rowData = [
      row.cells[0].textContent,
      row.cells[1].textContent,
      row.cells[2].textContent,
      row.cells[3].textContent,
      row.cells[4].textContent,
      row.cells[5].textContent,
    ];


    // Sumar el valor de la celda "Importe" a la variable "total"
    if (row.cells[4].textContent == 'CANCELADA')
    {
        var importe = (parseFloat(row.cells[5].textContent) * 0);
        row.cells[5].textContent = importe.toString(); // Actualizar el valor de la celda en la tabla
        var rowData = [
        row.cells[0].textContent,
        row.cells[1].textContent,
        row.cells[2].textContent,
        row.cells[3].textContent,
        row.cells[4].textContent,
        row.cells[5].textContent];
        console.log(row.cells[5].textContent)
    }
    else
    {
        var importe = parseFloat(row.cells[5].textContent);
    }
    total += importe;
    rows.push(rowData);
  }

  // Agregar el total a la matriz "rows"
  var totalRow = ["", "", "", "", "Total:", (total.toFixed(2)).toString()];
  rows.push(totalRow);

  // Crear el PDF
  var doc = new jsPDF();

  // Agregar imagen en la esquina superior izquierda
  var img = new Image();
  img.onload = function () {
    doc.addImage(this, "JPEG", 14, 10, 40, 30);
    // Obtener la fecha y hora actual
    var fecha = new Date().toLocaleTimeString([], {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    // Agregar la fecha y hora en la esquina superior derecha
    doc.text(fecha, doc.internal.pageSize.width - 55.5, 10);

    // Convertir la posición en milímetros a puntos
    var mmToPt = 2.835;

    // Agregar el título centrado y en letra de tamaño 16 con un desplazamiento en el eje y
    doc.setFontSize(22);
    var title = "Lista de Compras";
    var titleWidth =
      (doc.getStringUnitWidth(title) * doc.internal.getFontSize()) / mmToPt;
    var x = (doc.internal.pageSize.width - titleWidth) / 2;
    var y = 30;
    doc.text(title, x, y);

    // Agregar la tabla
    doc.autoTable({
      head: [
        ["N°","Fecha", "Proveedor", "Tipo de Pago", "Estado", "Importe"],
      ],
      body: rows,
      startY: 40, // Mover la tabla hacia abajo para evitar que cubra el título
      styles: { cell: { textAlign: 'center' } }
    });

    // Guardar el PDF
    doc.save("lista_compras.pdf");
  };
  img.onerror = function () {
    console.error("La imagen no se pudo cargar.");
  };
  img.src = "static/img/LogoReporte.jpeg";
}

document
  .getElementById("btnExportarCompras")
  .addEventListener("click", exportarPDF);
