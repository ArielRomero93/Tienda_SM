<script>
$(document).ready(function() {
    $(".ordenar").click(function() {
        var columna = $(this).index();
        var ordenActual = $(this).attr("orden");
        var orden = "";
        if (ordenActual == undefined || ordenActual == "desc") {
            orden = "asc";
            $(this).attr("orden", "asc");
        } else {
            orden = "desc";
            $(this).attr("orden", "desc");
        }
        var filas = $("#dataTable tbody>tr").get();
        filas.sort(function(a, b) {
            var valorA = $(a).children("td").eq(columna).text().toUpperCase();
            var valorB = $(b).children("td").eq(columna).text().toUpperCase();
            if ($.isNumeric(valorA) && $.isNumeric(valorB)) {
                return valorA - valorB;
            } else {
                return (valorA < valorB) ? -1 : (valorA > valorB) ? 1 : 0;
            }
        });
        if (orden == "desc") {
            filas.reverse();
        }
        $.each(filas, function(index, fila) {
            $("#dataTable tbody").append(fila);
        });
    });
});
</script>
