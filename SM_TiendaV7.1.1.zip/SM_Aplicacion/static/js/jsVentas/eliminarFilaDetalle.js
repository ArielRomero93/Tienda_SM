// Selecciona todos los botones de eliminar fila de detalle
const eliminarBotones = document.querySelectorAll('.eliminar-fila-detalle');
console.log(eliminarBotones);
// Agrega un listener de evento clic para cada botón
eliminarBotones.forEach(boton => {
  boton.addEventListener('click', () => {
    // Obtén el elemento padre del botón (la fila de detalle)
    const filaDetalle = boton.parentElement.parentElement;
    
    // Elimina la fila de detalle del DOM
    console.log("Intenta");
    filaDetalle.remove();
  });
});
