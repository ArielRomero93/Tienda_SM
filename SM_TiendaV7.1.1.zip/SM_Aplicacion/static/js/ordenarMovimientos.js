//Función que invierte el orden de las filas en la tabla
function reverseTable() {
  var table = document.getElementById("dataTable");
  for (var i = 1, row; (row = table.rows[i]); i++) {
    table.insertBefore(row, table.firstChild);
  }
}

//Agregar un evento click al botón para invertir la tabla
document
  .getElementById("btnReverseTable")
  .addEventListener("click", function () {
    reverseTable();
    console.log("revertir");
  });
