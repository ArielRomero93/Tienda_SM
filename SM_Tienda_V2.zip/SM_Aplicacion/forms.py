from django import forms
from django.forms import inlineformset_factory
from .models import Clientes, Proveedores, Productos, Ventas, VentaDetalle


class ClienteReadOnlyForm(forms.ModelForm):
    class Meta:
        model = Clientes
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'readonly': True}),
            'numeroDocumento': forms.TextInput(attrs={'readonly': True}),
            'email': forms.EmailInput(attrs={'readonly': True}),
            'telefono': forms.TextInput(attrs={'readonly': True}),
            'direccion': forms.TextInput(attrs={'readonly': True})
        }


class ClientesForm(forms.ModelForm):
    class Meta:
        model = Clientes
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'numeroDocumento': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'})
        }


class ProveedoresForm(forms.ModelForm):
    class Meta:
        model = Proveedores
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'numeroDocumento': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'})
        }


class ProductosForm(forms.ModelForm):
    class Meta:
        model = Productos
        fields = "__all__"
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
            'talle': forms.TextInput(attrs={'class': 'form-control'}),
            'categoria': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precioCosto': forms.NumberInput(attrs={'class': 'form-control'})
        }

class VentasForm(forms.ModelForm):
    class Meta:
        model = Ventas
        fields = "__all__"
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'idCliente': forms.ModelChoiceField(queryset=Clientes.objects.all(), empty_label=None),
            'idEstado': forms.Select(attrs={'class': 'form-control', 'disabled': 'disabled'}),
            'idTipoPago': forms.Select(attrs={'class': 'form-control'}),
            'precioTotal': forms.NumberInput(attrs={'class': 'form-control', 'disabled': 'disabled'})
        }

class VentaDetalleForm(forms.ModelForm):
    class Meta:
        model = VentaDetalle
        fields = "__all__"
        widgets = {
            'idProducto': forms.Select(attrs={'class': 'form-control'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
            'precioUnitario': forms.NumberInput(attrs={'class': 'form-control'}),
            'subTotal': forms.NumberInput(attrs={'class': 'form-control'})
        }
        labels = {
            'idProducto': 'Producto'
        }

VentaDetalleFormset = inlineformset_factory(
    Ventas, VentaDetalle, form=VentaDetalleForm, extra=10
)
# class VentasForm(forms.ModelForm):
#     class Meta:
#         model = Ventas
#         fields = "__all__"
#         widgets = {
#             'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
#             'idCliente': forms.ModelChoiceField(queryset=Clientes.objects.all(), empty_label=None),
#             'idEstado': forms.Select(attrs={'class': 'form-control', 'disabled': 'disabled'}),
#             'idTipoPago': forms.Select(attrs={'class': 'form-control'}),
#             'precioTotal': forms.NumberInput(attrs={'class': 'form-control', 'disabled': 'disabled'})
#         }
#
# class VentaDetalleForm(forms.ModelForm):
#     class Meta:
#         model = VentaDetalle
#         fields = "__all__"
#         widgets = {
#             'idProducto': forms.Select(attrs={'class': 'form-control'}),
#             'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
#             'precioUnitario': forms.NumberInput(attrs={'class': 'form-control'}),
#             'subTotal': forms.NumberInput(attrs={'class': 'form-control'})
#         }
#         labels = {
#             'idProducto': 'Producto'
#         }
#
# VentaDetalleFormset = inlineformset_factory(
#     Ventas, VentaDetalle, form=VentaDetalleForm, extra=10
# )




# class VentaDetalleForm(forms.ModelForm):
#     class Meta:
#         model = VentaDetalle
#         idProdcuto = forms.ModelChoiceField(queryset=Productos.objects.all(), empty_label=None,
#                                             to_field_name="idProducto")
#         fields = "__all__"
#         widgets = {
#             'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
#             'subTotal': forms.NumberInput(attrs={'class': 'form-control'})
#
#         }
# class VentasForm(forms.ModelForm):
#     class Meta:
#         model = Ventas
#         fields = "__all__"
#         widgets = {
#             'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
#             'idCliente' : forms.ModelChoiceField(queryset=Clientes.objects.all(), empty_label=None),
#             'idTipoPago': forms.Select(attrs={'class': 'form-control'}),
#             'precioTotal': forms.NumberInput(attrs={'class': 'form-control'})
#         }
#
# class DetalleVentasForm(forms.ModelForm):
#     class Meta:
#         model = VentaDetalle
#         fields = '__all__'
#         widgets = {
#             'idProducto': forms.ModelChoiceField(queryset=Productos.objects.all(), empty_label=None),
#             'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
#             'subTotal': forms.NumberInput(attrs={'class': 'form-control'})
#
#         }
#
# DetalleVentasInlineFormset = forms.inlineformset_factory(
#     Ventas,
#     VentaDetalle,
#     form=DetalleVentasForm,
#     extra=10
# )
