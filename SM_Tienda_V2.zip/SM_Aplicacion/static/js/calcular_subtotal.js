$(document).ready(function() {
    // calcular subtotal al cargar la página
    calcularSubtotales();

    // calcular subtotal al cambiar la cantidad o el precio unitario
    $('.cantidad, .precio-unitario').on('change', function() {
        calcularSubtotal($(this).closest('.detalle-formset-row'));
    });
});

function calcularSubtotal(row) {
    var cantidad = parseFloat(row.find('.cantidad').val());
    var precioUnitario = parseFloat(row.find('.precio-unitario').val());
    var subtotal = cantidad * precioUnitario || 0;
    row.find('.subtotal').val(subtotal.toFixed(2));
    calcularSubtotales();
}

function calcularSubtotales() {
    var subtotales = 0;
    $('.subtotal').each(function() {
        subtotales += parseFloat($(this).val()) || 0;
    });
    $('#id_total').val(subtotales.toFixed(2));
}
