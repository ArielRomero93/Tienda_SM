// Código para agregar nuevos detalles de venta
  $(document).ready(function() {
    $('#add-detalle').click(function() {
      var formCount = parseInt($('#id_venta_detalle-TOTAL_FORMS').val());
      var row = $('.detalle-formset-row').last().clone();
      row.find('input, select').each(function() {
        var name = $(this).attr('name').replace('-' + (formCount - 1) + '-', '-' + formCount + '-');
        $(this).attr({'name': name, 'id': 'id_' + name});
        $(this).val('');
      });
      row.insertAfter($('.detalle-formset-row').last());
      $('#id_venta_detalle-TOTAL_FORMS').val(formCount + 1);
    });