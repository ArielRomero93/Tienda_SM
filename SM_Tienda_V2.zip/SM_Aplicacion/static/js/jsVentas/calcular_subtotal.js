//
//  $(document).ready(function() {
//    // función para calcular el subtotal
//    function calcularSubtotal(row) {
//      var cantidad = parseFloat(row.find('input[name$="cantidad"]').val());
//      var precioUnitario = parseFloat(row.find('input[name$="precioUnitario"]').val());
//      if (!isNaN(cantidad) && !isNaN(precioUnitario)) {
//        var subtotal = cantidad * precioUnitario;
//        row.find('input[name$="subTotal"]').val(subtotal.toFixed(2));
//      } else {
//        row.find('input[name$="subTotal"]').val('');
//      }
//    }
//
//    // evento para calcular el subtotal al cambiar la cantidad o el precio unitario
//    $('.detalle-formset-row').on('change', 'input[name$="cantidad"], input[name$="precioUnitario"]', function() {
//      var row = $(this).closest('.detalle-formset-row');
//      calcularSubtotal(row);
//    });
//  });
//

//$(document).ready(function() {
//    // Seleccione todos los campos de cantidad y precio unitario.
//    +
//    var cantidadFields = $(".cantidad");
//    var precioUnitarioFields = $(".precio-unitario");
//
//    // Agregue un controlador de eventos al evento "cambio" para cada campo de cantidad y precio unitario.
//    cantidadFields.change(function() {
//        actualizarSubtotal(this);
//    });
//    precioUnitarioFields.change(function() {
//        actualizarSubtotal(this);
//    });
//
//    // Función para actualizar el campo de subtotal correspondiente en función de la cantidad y el precio unitario.
//    function actualizarSubtotal(input) {
//        // Obtener el valor de cantidad y precio unitario.
//        var cantidad = $(input).closest(".detalle-formset-row").find(".cantidad").val();
//        var precioUnitario = $(input).closest(".detalle-formset-row").find(".precio-unitario").val();
//
//        // Calcular el subtotal.
//        var subtotal = cantidad * precioUnitario;
//
//        // Actualizar el valor del campo de subtotal.
//        $(input).closest(".detalle-formset-row").find(".subTotal").val(subtotal);
//    }
//});

//$(document).ready(function() {
//    // Agregue un controlador de eventos al evento "cambio" para cada campo de cantidad y precio unitario.
//    $("#detalle-formset").on("change", ".cantidad, .precio-unitario", function() {
//        actualizarSubtotal(this);
//    });
//
//    // Función para actualizar el campo de subtotal correspondiente en función de la cantidad y el precio unitario.
//    function actualizarSubtotal(input) {
//        // Obtener la fila de detalle correspondiente.
//        var detalleRow = $(input).closest(".detalle-formset-row");
//
//        // Obtener el valor de cantidad y precio unitario.
//        var cantidad = detalleRow.find(".cantidad").val();
//        var precioUnitario = detalleRow.find(".precio-unitario").val();
//
//        // Calcular el subtotal.
//        var subtotal = cantidad * precioUnitario;
//
//        // Actualizar el valor del campo de subtotal.
//        detalleRow.find(".subTotal").val(subtotal);
//        console.log(`cantidad: ${cantidad}, precio unitario: ${preciounitario}`);
//    }
//});


$(document).on('change', '.detalle-formset-row input', function() {
	var row = $(this).closest('.detalle-formset-row');
	var cantidad = row.find('input[name$="cantidad"]').val();
	var preciounitario = row.find('input[name$="precioUnitario"]').val();
	var subtotal = cantidad * preciounitario;
	row.find('input[name$="subTotal"]').val(subtotal.toFixed(2));
	console.log(`cantidad: ${cantidad}, precio unitario: ${preciounitario}`);
});

$(document).on('click', '#add-detalle', function() {
	var form_idx = $('#id_venta_detalle-TOTAL_FORMS').val();
	$('#detalle-formset').append($('#empty-form').html().replace(/__prefix__/g, form_idx));
	$('#id_venta_detalle-TOTAL_FORMS').val(parseInt(form_idx) + 1);
})