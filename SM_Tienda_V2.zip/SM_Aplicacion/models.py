from django.db import models
from django.urls import reverse


# Create your models here.

# Clientes
class Clientes(models.Model):
    nombre = models.CharField(max_length=200, verbose_name='Nombre')
    numeroDocumento = models.CharField(max_length=13, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.nombre


# Proveedores
class Proveedores(models.Model):
    nombre = models.CharField(max_length=200, verbose_name='Nombre')
    numeroDocumento = models.CharField(max_length=13, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=15, blank=True)
    direccion = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.nombre


# Productos

class Productos(models.Model):
    CATEGORIAS = (
        ('indumentaria', 'Indumentaria'),
        ('accesorios', 'Accesorios'),
        ('calzado', 'Calzado'),
        ('calzadoNinio', 'Calzado Niño'),
    )
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    talle = models.CharField(max_length=10, verbose_name='Talle en Leta o Numero', default='')
    categoria = models.CharField(choices=CATEGORIAS, verbose_name='Categoria', max_length=20)
    precioCosto = models.DecimalField(max_digits=8, decimal_places=2, blank=True)
    cantidad = models.PositiveIntegerField(default=0)


    def __str__(self):
        return self.nombre


# Ventas

class Ventas(models.Model):
    EFECTIVO = 'EF'
    TARJETACREDITO = 'TC'
    TARJETADEBITO = 'TD'
    CUENTACORRIENTE = 'CC'
    TRANSFERENCIA = 'TR'
    TIPOPAGO = [
        (EFECTIVO, 'Efectivo'),
        (TARJETACREDITO, 'Tarjeta de Credito'),
        (TARJETADEBITO, 'Tarjeta de Debito'),
        (CUENTACORRIENTE, 'Cuenta Corriente'),
        (TRANSFERENCIA, 'Transferencia')
    ]

    FINALIZADA = 'FI'
    ANULADA = 'AN'
    ESTADO = [
        (FINALIZADA, 'FINALIZADA'),
        (ANULADA, 'ANULADA')
    ]
    fecha = models.DateTimeField(auto_now_add=True)
    idcliente = models.ForeignKey(Clientes, on_delete=models.CASCADE)
    idTipoPago = models.CharField(choices=TIPOPAGO, max_length= 3, default=EFECTIVO)
    idEstado = models.CharField(choices=ESTADO, max_length= 3, default=FINALIZADA)
    precioTotal = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f'{self.fecha} - {self.idcliente.name} - ${self.precioTotal}'


class VentaDetalle(models.Model):
    idVenta = models.ForeignKey(Ventas, on_delete=models.CASCADE)
    idProducto = models.ForeignKey(Productos, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precioUnitario = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    subTotal = models.DecimalField(max_digits=10, decimal_places=2)


    def __str__(self):
        return f'{self.idProducto.name}- {self.cantidad} - $ {self.subTotal}'
